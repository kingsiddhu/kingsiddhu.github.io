﻿素材提供元
効果音：©BBC http://bbcsfx.acropolis.org.uk/